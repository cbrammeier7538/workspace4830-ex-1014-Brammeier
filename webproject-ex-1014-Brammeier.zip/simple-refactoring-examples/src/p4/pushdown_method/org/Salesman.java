package p4.pushdown_method.org;

public class Salesman extends Employee {
}
